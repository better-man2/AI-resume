/**
 * @projectName springAi
 * @package com.shanzhu.biographical.websocket
 * @className com.shanzhu.biographical.websocket.OpenAiChatModel
 * @copyright Copyright 2024 Thunisoft, Inc All rights reserved.
 */
package com.shanzhu.biographical.websocket;

import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
public class wsOpenAiChatModel {

    @Autowired
    private OpenAiChatModel openAiChatModel;

    // 接收消息msg并返回流式数据
    public Flux<String> stream(String msg) {
        // 将msg传递给openAiChatModel并返回流式数据
        return openAiChatModel.stream(msg);
    }
}

